//------------------------------------------------------------------------
//
//	Socialite class header
//
//	This class creates text and HTML output representing a person's
//	first and last name, a picture, and a website link with a
//	description
//
//------------------------------------------------------------------------
//
//	Author: Benjamin Burke - bdb55
//	Date: April 2017
//
//------------------------------------------------------------------------
#ifndef __socialite_h__
#define __socialite_h__
#include <iostream>
#include <string>
using namespace std;
class socialite
{
public:

	    //------------------------------------------------------
	    //----- Constructors -----------------------------------
	    //------------------------------------------------------

    socialite();
    socialite(string a, string b, string c, string d, string e, string f);

	    //------------------------------------------------------
	    //----- Destructor -------------------------------------
	    //------------------------------------------------------

    ~socialite();

	    //------------------------------------------------------
	    //----- Inspectors -------------------------------------
	    //------------------------------------------------------

    string getLast() const;
    string getFirst() const;
    string getUserID() const;
    string getPicture() const;
    string getURL() const;
    string getDescription() const;

	    //------------------------------------------------------
	    //----- Mutators ---------------------------------------
	    //------------------------------------------------------

    void setLast(string str);
    void setFirst(string str);
    void setUserID(string str);
    void setPicture(string str);
    void setURL(string str);
    void setDescription(string str);

	    //------------------------------------------------------
	    //----- Facilitators -----------------------------------
	    //------------------------------------------------------

    void outputText(ostream &os);
    void outputHTML(ostream &os);

private:

    string lastName_;
    string firstName_;
    string userID_;
    string picture_;
    string webURL_;
    string description_;
};
#endif