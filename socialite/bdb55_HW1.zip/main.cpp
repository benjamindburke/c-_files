//------------------------------------------------------------------------
//
//	Socialite class tester (main)
//
//	This class creates text and HTML output representing a person's
//	first and last name, a picture, and a website link with a
//	description
//
//------------------------------------------------------------------------
//
//	Author: Benjamin Burke - bdb55
//	Date: April 2017
//
//------------------------------------------------------------------------

#include <string>
#include <iostream>
#include <fstream>
#include "socialite.h"
using namespace std;

int main (void)
{
    socialite ben;

    cout << "Testing set functions..." << endl;
    ben.setFirst("Ben");
    ben.setLast("Burke");
    ben.setUserID("user1");
    ben.setPicture("https://pbs.twimg.com/profile_images/833711203092463617/DjajZur1_400x400.jpg");
    ben.setURL("http://www.twitter.com/benjamindburke");
    ben.setDescription("It's my personal twitter!");

    cout << "\nTesting get functions..." << endl << ben.getFirst() << endl;
    cout << ben.getLast() << endl;
    cout << ben.getUserID() << endl;
    cout << ben.getPicture() << endl;
    cout << ben.getURL() << endl;
    cout << ben.getDescription() << endl;
    cout << "\nTesting text output and HTML output using cout" << endl;
    ben.outputText(cout);
    ben.outputHTML(cout);

    cout << "\nSetting other socialites..." << endl;
    socialite joe("Rogan", "Joe", "user2", "https://pbs.twimg.com/profile_images/552307347851210752/vrXDcTFC.jpeg", "http://www.omfgdogs.com", "el diablo");
    joe.outputText(cout);
    socialite mitch("McConnell", "Mitch", "user3", "https://theintellectualist.co/wp-content/uploads/2017/02/wpid-mitch-mcconnell.jpg", "http://www.democrats.org/", "I'm an absolute spineless cuck"),
	      rick("Sanchez", "Rick", "user4", "https://pbs.twimg.com/profile_images/639118835728171008/QOEK5nOZ.jpg", "https://earth.galacticfederation.com", "#SzechuanSauce"),
	      will("Ntsoane", "William", "user5", "https://pbs.twimg.com/profile_images/831355040367595523/tux2TO6R_400x400.jpg", "https://www.nature.org", "he's my best friend at home!");

    cout << "\nOutput being printed to files." << endl;

    ofstream usert1, userh1, usert2, userh2, usert3, userh3, usert4, userh4, usert5, userh5;
    usert1.open("user1.txt", ios::out); userh1.open("user1.html", ios::out);
    usert2.open("user2.txt", ios::out); userh2.open("user2.html", ios::out);
    usert3.open("user3.txt", ios::out); userh3.open("user3.html", ios::out);
    usert4.open("user4.txt", ios::out); userh4.open("user4.html", ios::out);
    usert5.open("user5.txt", ios::out); userh5.open("user5.html", ios::out);
    ben.outputText(usert1); ben.outputHTML(userh1);
    joe.outputText(usert2); joe.outputHTML(userh2);
    mitch.outputText(usert3); mitch.outputHTML(userh3);
    rick.outputText(usert4); rick.outputHTML(userh4);
    will.outputText(usert5); will.outputHTML(userh5);
    return 0;
}