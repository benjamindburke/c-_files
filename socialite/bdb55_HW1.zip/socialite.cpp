//------------------------------------------------------------------------
//
//	Socialite class implementation
//
//	This class creates text and HTML output representing a person's
//	first and last name, a picture, and a website link with a
//	description
//
//------------------------------------------------------------------------
//
//	Author: Benjamin Burke - bdb55
//	Date: April 2017
//
//------------------------------------------------------------------------

#include <iostream>
#include <string>
#include "socialite.h"
using namespace std;

	//-----------------------------------------------------------------------
	//----- Constructors ----------------------------------------------------
	//-----------------------------------------------------------------------

socialite::socialite()
{
    lastName_ = "";
    firstName_ = "";
    userID_ = "";
    picture_ = "";
    webURL_ = "";
    description_ = "";
}

socialite::socialite(string last, string first, string user, string pic, string url, string desc)
{
    lastName_ = last;
    firstName_ = first;
    userID_ = user;
    picture_ = pic;
    webURL_ = url;
    description_ = desc;
}
	
	//-----------------------------------------------------------------------
	//----- Destructor ------------------------------------------------------
	//-----------------------------------------------------------------------

socialite::~socialite() { }

	//-----------------------------------------------------------------------
	//----- Inspectors ------------------------------------------------------
	//-----------------------------------------------------------------------

string socialite::getLast() const
{
    return lastName_;
}

string socialite::getFirst() const
{
    return firstName_;
}

string socialite::getUserID() const 
{
    return userID_;
}

string socialite::getPicture() const
{
    return picture_;
}

string socialite::getURL() const
{
    return webURL_;
}

string socialite::getDescription() const
{
    return description_;
}

	//-----------------------------------------------------------------------
	//----- Mutators --------------------------------------------------------
	//-----------------------------------------------------------------------

void socialite::setLast(string str)
{
    lastName_ = str;
}

void socialite::setFirst(string str)
{
    firstName_ = str;
}

void socialite::setUserID(string str)
{ 
    userID_ = str;
}

void socialite::setPicture(string str)
{
    picture_ = str;
}

void socialite::setURL(string str)
{
    webURL_ = str;
}

void socialite::setDescription(string str)
{
    description_ = str;
}

	//-----------------------------------------------------------------------
	//----- Facilitators ----------------------------------------------------
	//-----------------------------------------------------------------------

void socialite::outputText(ostream &os) //output text suitable for terminal or .txt formatting
{
    os << "First name: " << firstName_ << endl;
    os << "Last name : " << lastName_ << endl;
    os << "User ID: " << userID_ << endl;
    os << "Picture: " << picture_ << endl;
    os << "Website: " << webURL_ << endl;
    os << "Website description: " << description_ << endl;
}

void socialite::outputHTML(ostream &os) //output text in HTML format
{
    os << "<!doctype html>\n<html>" << endl;
    os << "  <head>\n    <title>" << firstName_ << " " << lastName_ << "'s Socialite</title>\n  </head>" << endl;
    os << "  <body>\n  <center>" << endl;
    os << "    <h2>" << userID_ << "</h3>" << endl;
    os << "    <h3>" << firstName_ << " " << lastName_ << "</h3>" << endl;
    os << "    <img src=\"" << picture_ << "\"></img>\n    <hr>" << endl;
    os << "    " << firstName_ << " wants to share <a HREF=\"" << webURL_ << "\">" << description_ << "</a> with you:" << endl;
    os << "    <br>    " << webURL_ << endl;
    os << "  </center>\n  </body>\n</html>" << endl;
}

